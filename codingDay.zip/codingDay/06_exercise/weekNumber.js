

let numbers=[1,2,3,4,5,6,7];

let day= ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","sunday"];

function weekNumbersToWords(val){
    let num=4;
    for(let i=0;i<val.length;i++){
        let num=4;
    switch(num){
    
 case 1:console.log("The day is"+val[i]);
        break;
  case 2: console.log("The day is"+val[i]);      
            break;
case 3: console.log("The day is"+val[i]);      
            break;
case 4: console.log("The day is"+val[i]);      
            break;
case 5: console.log("The day is"+val[i]);      
            break;
case 6: console.log("The day is"+val[i]);      
        break; 
case 7: console.log("The day is"+val[i]);      
       break;


}}}
console.log(weekNumbersToWords(day));