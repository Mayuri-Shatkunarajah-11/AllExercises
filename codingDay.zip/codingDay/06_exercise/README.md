Write a function called *weekNumbersToWords* with given given input array of numbers 1-7 and outputs an array of the weeksdays written out. You must use a switch, not if/else.

Example: <br>
Input: [1,4,6,3,2] <br>
Output: ["Monday","Thursday","Saturday","Wednesday","Tuesday"]

Estimated time: 30 minutes <br>
Total points: 30
