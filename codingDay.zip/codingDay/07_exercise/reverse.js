let number=Number(prompt("Enter the number"));

function reverseFunction(num){
  let value=[];
  value=num;
let reversenumber=value.reverse();
   console.log(reversenumber);
   
}
reverseFunction(number);