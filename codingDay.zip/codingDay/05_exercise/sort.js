let day=["Monday","Thursday","Saturday","Wednesday","Tuesday"] ;


function getFirstValue(d){
for(let i=0; i<d.length;i++){
let val=d.sort();
console.log("The sorted value"+val);
}

}
getFirstValue(day);

